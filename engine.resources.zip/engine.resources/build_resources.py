#!/usr/bin/env python3
import os
import json
import hashlib
import zipfile
from datetime import datetime

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
EDITOR_DIR = os.path.join(ROOT_DIR, "editor")
ZIP_PATH = os.path.join(ROOT_DIR, "editor-resources.zip")
MANIFEST_PATH = os.path.join(ROOT_DIR, "manifest.json")

def create_zip():
    print("📦 Packing editor resources into editor-resources.zip...")
    with zipfile.ZipFile(ZIP_PATH, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(EDITOR_DIR):
            for file in files:
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, ROOT_DIR)
                zipf.write(full_path, rel_path)
                print(f"  + Added: {rel_path}")

def compute_sha256(file_path):
    sha256 = hashlib.sha256()
    with open(file_path, 'rb') as f:
        while chunk := f.read(8192):
            sha256.update(chunk)
    return sha256.hexdigest()

def update_manifest(sha256_hash, zip_size):
    print("📝 Updating manifest.json...")
    if os.path.exists(MANIFEST_PATH):
        with open(MANIFEST_PATH, 'r', encoding='utf-8') as f:
            manifest = json.load(f)
    else:
        manifest = {}

    manifest["zip_size_bytes"] = zip_size
    manifest["sha256"] = sha256_hash
    manifest["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with open(MANIFEST_PATH, 'w', encoding='utf-8') as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)
    print("✅ manifest.json updated successfully!")

if __name__ == "__main__":
    if not os.path.exists(EDITOR_DIR):
        print(f"❌ Error: {EDITOR_DIR} directory does not exist.")
        exit(1)

    create_zip()
    size = os.path.getsize(ZIP_PATH)
    sha256 = compute_sha256(ZIP_PATH)
    print(f"🔒 SHA256: {sha256}")
    print(f"📊 Size: {size} bytes")
    update_manifest(sha256, size)
    print("🚀 Build complete! Ready to push to GitHub.")
